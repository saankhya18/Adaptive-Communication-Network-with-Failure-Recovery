#!/usr/bin/env bash
set -e
mkdir -p results
python3 experiments/run_experiments.py --output results
