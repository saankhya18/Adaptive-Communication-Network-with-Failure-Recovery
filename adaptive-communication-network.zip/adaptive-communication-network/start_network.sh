#!/usr/bin/env bash
set -e
sudo python3 topology/adaptive_topology.py
