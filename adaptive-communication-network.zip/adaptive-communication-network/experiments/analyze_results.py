import argparse
import csv

def main():
    p = argparse.ArgumentParser()
    p.add_argument("files", nargs="+")
    args = p.parse_args()
    for name in args.files:
        print("\n" + name)
        with open(name, newline="") as f:
            for row in csv.DictReader(f):
                print(row)

if __name__ == "__main__":
    main()
