import argparse
import csv
import os

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="results")
    p.add_argument("--count", type=int, default=600)
    p.add_argument("--interval", type=float, default=0.05)
    args = p.parse_args()

    os.makedirs(args.output, exist_ok=True)
    path = os.path.join(args.output, "experiment_plan.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["mode","count","interval","failure"])
        w.writerow(["adaptive",args.count,args.interval,"s1-s2"])
    print(path)

if __name__ == "__main__":
    main()
