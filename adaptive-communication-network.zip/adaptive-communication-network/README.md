# Adaptive Communication Network with Failure Recovery

## Project 30 - UDP / SDN / Mininet

A resilient UDP communication framework where an SDN controller detects a network failure and dynamically reroutes application traffic through an alternate path.

### Topology

```text
                 s2
                /  \
h1 ---- s1 ----     ---- s4 ---- h2
                \  /
                 s3
```

Primary path: `s1 -> s2 -> s4`  
Backup path: `s1 -> s3 -> s4`

### Requirements

- Ubuntu 20.04/22.04 recommended
- Python 3
- Mininet
- Open vSwitch
- Ryu or OS-Ken
- sudo access

### Install

```bash
chmod +x *.sh
sudo ./install.sh
```

### Run

Terminal 1:
```bash
sudo ./start_controller.sh
```

Terminal 2:
```bash
sudo ./start_network.sh
```

In Mininet:
```text
h2 python3 app/udp_server.py --bind 10.0.0.2 --port 5001
```

Then from another Mininet terminal:
```text
h1 python3 app/udp_client.py --server 10.0.0.2 --port 5001 --count 600 --interval 0.05
```

While traffic is running:
```text
link s1 s2 down
```

The controller should recompute the surviving path through `s3`.

Restore:
```text
link s1 s2 up
```

Cleanup:
```bash
sudo ./cleanup.sh
```

### Tests

```bash
python3 tests/test_protocol.py
python3 tests/test_path_computation.py
```

### Flow inspection

```bash
sudo ovs-ofctl -O OpenFlow13 dump-flows s1
```

### Metrics

The application/project records packet count, packet loss, latency and recovery observations. Do not put invented numerical results in a report. Use values obtained from actual runs.

### Repository structure

```text
app/          UDP client/server, protocol and metrics
controller/   SDN controller and path computation
topology/     Mininet topology
experiments/  experiment and analysis scripts
tests/        unit tests
docs/         architecture, testing, performance, demo, viva, troubleshooting
```
