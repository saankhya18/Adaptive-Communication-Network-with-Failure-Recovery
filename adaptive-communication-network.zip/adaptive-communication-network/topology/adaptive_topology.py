from mininet.net import Mininet
from mininet.node import OVSSwitch, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel
from mininet.link import TCLink

def build():
    net = Mininet(controller=RemoteController, switch=OVSSwitch,
                  link=TCLink, autoSetMacs=True, build=False)
    c0 = net.addController("c0", controller=RemoteController,
                           ip="127.0.0.1", port=6653)

    h1 = net.addHost("h1", ip="10.0.0.1/24")
    h2 = net.addHost("h2", ip="10.0.0.2/24")

    s1 = net.addSwitch("s1", protocols="OpenFlow13")
    s2 = net.addSwitch("s2", protocols="OpenFlow13")
    s3 = net.addSwitch("s3", protocols="OpenFlow13")
    s4 = net.addSwitch("s4", protocols="OpenFlow13")

    net.addLink(h1, s1, bw=10, delay="2ms")
    net.addLink(s1, s2, bw=10, delay="10ms")
    net.addLink(s2, s4, bw=10, delay="10ms")
    net.addLink(s1, s3, bw=10, delay="20ms")
    net.addLink(s3, s4, bw=10, delay="20ms")
    net.addLink(s4, h2, bw=10, delay="2ms")

    net.build()
    c0.start()
    for sw in (s1, s2, s3, s4):
        sw.start([c0])
    return net

if __name__ == "__main__":
    setLogLevel("info")
    net = build()
    CLI(net)
    net.stop()
