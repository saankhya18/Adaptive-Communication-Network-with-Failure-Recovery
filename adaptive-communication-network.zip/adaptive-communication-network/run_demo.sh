#!/usr/bin/env bash
python3 run_demo.py
