#!/usr/bin/env bash
watch -n 1 'sudo ovs-ofctl -O OpenFlow13 dump-flows s1'
