from heapq import heappop, heappush

def build_graph(links):
    graph = {}
    for a, b in links:
        graph.setdefault(a, set()).add(b)
        graph.setdefault(b, set()).add(a)
    return graph

def shortest_path(graph, source, target):
    queue = [(0, source, [source])]
    seen = {source}
    while queue:
        distance, node, path = heappop(queue)
        if node == target:
            return path
        for nxt in graph.get(node, ()):
            if nxt not in seen:
                seen.add(nxt)
                heappush(queue, (distance + 1, nxt, path + [nxt]))
    return []
