import logging
import time

try:
    from ryu.base import app_manager
    from ryu.controller import ofp_event
    from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
    from ryu.ofproto import ofproto_v1_3
    from ryu.lib.packet import packet, ethernet
    from ryu.topology import event
    from ryu.topology.api import get_all_link
except ImportError:
    from os_ken.base import app_manager
    from os_ken.controller import ofp_event
    from os_ken.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
    from os_ken.ofproto import ofproto_v1_3
    from os_ken.lib.packet import packet, ethernet
    from os_ken.topology import event
    from os_ken.topology.api import get_all_link

from path_computation import build_graph, shortest_path

LOG = logging.getLogger("adaptive-controller")
LOG.setLevel(logging.INFO)

class AdaptiveController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.datapaths = {}
        self.mac_to_port = {}
        self.current_path = []
        self.last_change = 0

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features(self, ev):
        dp = ev.msg.datapath
        self.datapaths[dp.id] = dp
        parser = dp.ofproto_parser
        ofp = dp.ofproto
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofp.OFPP_CONTROLLER, ofp.OFPCML_NO_BUFFER)]
        self.add_flow(dp, 0, match, actions)
        LOG.info("Switch %s connected", dp.id)

    def add_flow(self, dp, priority, match, actions):
        parser = dp.ofproto_parser
        ofp = dp.ofproto
        instructions = [parser.OFPInstructionActions(ofp.OFPIT_APPLY_ACTIONS, actions)]
        dp.send_msg(parser.OFPFlowMod(
            datapath=dp, priority=priority, match=match,
            instructions=instructions))

    def links(self):
        return [(str(l.src.dpid), str(l.dst.dpid))
                for l in get_all_link(self, None)]

    def recompute(self, reason):
        graph = build_graph(self.links())
        path = shortest_path(graph, "1", "4")
        if path != self.current_path:
            old = self.current_path
            self.current_path = path
            LOG.warning("PATH_CHANGE reason=%s old=%s new=%s", reason, old, path)
        if path:
            self.install_path(path)

    def port_toward(self, dpid, neighbor):
        for link in get_all_link(self, None):
            if link.src.dpid == dpid and link.dst.dpid == neighbor:
                return link.src.port_no
        return None

    def install_path(self, path):
        if len(path) < 2:
            return
        for i, sw_name in enumerate(path):
            dpid = int(sw_name)
            dp = self.datapaths.get(dpid)
            if not dp:
                continue
            parser = dp.ofproto_parser
            out_port = self.port_toward(dpid, int(path[i + 1])) if i + 1 < len(path) else 2
            if out_port is None:
                continue

            forward = parser.OFPMatch(
                eth_type=0x0800, ipv4_src="10.0.0.1",
                ipv4_dst="10.0.0.2", ip_proto=17, udp_dst=5001)
            self.add_flow(dp, 100, forward, [parser.OFPActionOutput(out_port)])

            if i > 0:
                in_port = self.port_toward(dpid, int(path[i - 1]))
                if in_port is not None:
                    reverse = parser.OFPMatch(
                        eth_type=0x0800, ipv4_src="10.0.0.2",
                        ipv4_dst="10.0.0.1", ip_proto=17, udp_src=5001)
                    self.add_flow(dp, 100, reverse,
                                  [parser.OFPActionOutput(in_port)])

    @set_ev_cls([event.EventLinkAdd, event.EventLinkDelete])
    def link_event(self, ev):
        now = time.monotonic()
        if now - self.last_change < 0.2:
            return
        self.last_change = now
        LOG.warning("TOPOLOGY_CHANGE %s", type(ev).__name__)
        self.recompute(type(ev).__name__)

    @set_ev_cls(ofp_event.EventOFPPortStatus, MAIN_DISPATCHER)
    def port_status(self, ev):
        LOG.warning("PORT_STATUS switch=%s reason=%s",
                    ev.msg.datapath.id, ev.msg.reason)
        self.recompute("port-status")

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in(self, ev):
        msg = ev.msg
        dp = msg.datapath
        parser = dp.ofproto_parser
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if not eth:
            return

        dpid = dp.id
        in_port = msg.match["in_port"]
        self.mac_to_port.setdefault(dpid, {})[eth.src] = in_port
        out_port = self.mac_to_port[dpid].get(eth.dst, dp.ofproto.OFPP_FLOOD)
        actions = [parser.OFPActionOutput(out_port)]

        if out_port != dp.ofproto.OFPP_FLOOD:
            self.add_flow(dp, 10,
                          parser.OFPMatch(in_port=in_port, eth_dst=eth.dst),
                          actions)

        data = None if msg.buffer_id != dp.ofproto.OFP_NO_BUFFER else msg.data
        dp.send_msg(parser.OFPPacketOut(
            datapath=dp, buffer_id=msg.buffer_id,
            in_port=in_port, actions=actions, data=data))
