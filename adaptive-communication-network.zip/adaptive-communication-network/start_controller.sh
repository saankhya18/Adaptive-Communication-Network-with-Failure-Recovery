#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/controller"
export PYTHONPATH="$PWD"
if command -v ryu-manager >/dev/null 2>&1; then
    exec ryu-manager --ofp-tcp-listen-port 6653 adaptive_controller.py
elif command -v osken-manager >/dev/null 2>&1; then
    exec osken-manager --ofp-tcp-listen-port 6653 adaptive_controller.py
else
    echo "Install Ryu or OS-Ken first."
    exit 1
fi
