import struct

MAGIC = b"ACN1"
DATA = 1
HEADER = struct.Struct("!4sBQdI")

def pack_data(seq, timestamp, payload=b""):
    return HEADER.pack(MAGIC, DATA, seq, timestamp, len(payload)) + payload

def unpack(raw):
    if len(raw) < HEADER.size:
        raise ValueError("packet too short")
    magic, kind, seq, timestamp, length = HEADER.unpack(raw[:HEADER.size])
    if magic != MAGIC:
        raise ValueError("invalid magic")
    return kind, seq, timestamp, raw[HEADER.size:HEADER.size + length]
