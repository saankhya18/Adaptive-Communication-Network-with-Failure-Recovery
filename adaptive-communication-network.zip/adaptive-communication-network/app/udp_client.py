import argparse
import csv
import socket
import time
from protocol import pack_data

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--server", default="10.0.0.2")
    p.add_argument("--port", type=int, default=5001)
    p.add_argument("--count", type=int, default=600)
    p.add_argument("--interval", type=float, default=0.05)
    p.add_argument("--payload-size", type=int, default=256)
    p.add_argument("--output", default="")
    args = p.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(0.01)
    rows = []

    for seq in range(args.count):
        ts = time.time()
        sock.sendto(pack_data(seq, ts, bytes(args.payload_size)),
                    (args.server, args.port))
        rows.append((seq, ts))
        try:
            while True:
                data, _ = sock.recvfrom(65535)
                if data.startswith(b"NACK:"):
                    print(data.decode(), flush=True)
        except socket.timeout:
            pass
        time.sleep(args.interval)

    if args.output:
        with open(args.output, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["seq", "send_time"])
            w.writerows(rows)

    print(f"Sent {args.count} UDP packets", flush=True)

if __name__ == "__main__":
    main()
