import csv
import statistics

class Metrics:
    def __init__(self):
        self.sent = 0
        self.received = 0
        self.latencies = []

    @property
    def loss_percent(self):
        return 100 * (self.sent - self.received) / self.sent if self.sent else 0

    @property
    def avg_latency_ms(self):
        return statistics.mean(self.latencies) * 1000 if self.latencies else 0

    def write_csv(self, path, mode, recovery_time=None):
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["mode","sent","received","loss_percent",
                        "avg_latency_ms","recovery_time_s"])
            w.writerow([mode, self.sent, self.received,
                        self.loss_percent, self.avg_latency_ms, recovery_time])
