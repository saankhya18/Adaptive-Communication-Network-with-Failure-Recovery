import argparse
import socket
import time
from protocol import unpack, DATA

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bind", default="10.0.0.2")
    p.add_argument("--port", type=int, default=5001)
    args = p.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((args.bind, args.port))
    print(f"UDP server listening on {args.bind}:{args.port}", flush=True)

    seen = set()
    while True:
        raw, addr = sock.recvfrom(65535)
        try:
            kind, seq, timestamp, payload = unpack(raw)
        except ValueError:
            continue
        if kind != DATA:
            continue

        latency = (time.time() - timestamp) * 1000
        gap = [n for n in range(max(0, seq - 20), seq) if n not in seen]
        seen.add(seq)

        print(f"DATA seq={seq} latency_ms={latency:.3f} missing={gap}", flush=True)
        if gap:
            sock.sendto(("NACK:" + ",".join(map(str, gap))).encode(), addr)

if __name__ == "__main__":
    main()
