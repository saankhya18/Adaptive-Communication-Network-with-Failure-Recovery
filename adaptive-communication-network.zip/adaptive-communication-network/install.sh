#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y mininet openvswitch-switch python3-pip python3-matplotlib
python3 -m pip install --user os-ken
echo "Installation complete."
