import sys
sys.path.insert(0, "app")
from protocol import pack_data, unpack, DATA

raw = pack_data(7, 123.5, b"hello")
kind, seq, ts, payload = unpack(raw)
assert kind == DATA and seq == 7 and ts == 123.5 and payload == b"hello"
print("protocol tests passed")
