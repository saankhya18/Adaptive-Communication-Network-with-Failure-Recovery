import sys
sys.path.insert(0, "controller")
from path_computation import build_graph, shortest_path

g = build_graph([("1","2"),("2","4"),("1","3"),("3","4")])
assert shortest_path(g, "1", "4") in (["1","2","4"], ["1","3","4"])
assert shortest_path(build_graph([("1","2")]), "1", "4") == []
print("path tests passed")
