#!/usr/bin/env bash
sudo mn -c
sudo pkill -f 'ryu-manager.*adaptive_controller' 2>/dev/null || true
sudo pkill -f 'osken-manager.*adaptive_controller' 2>/dev/null || true
echo "Cleaned up."
