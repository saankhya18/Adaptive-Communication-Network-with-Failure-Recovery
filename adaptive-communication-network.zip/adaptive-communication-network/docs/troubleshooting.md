# Troubleshooting

If the controller cannot be found, install Ryu or OS-Ken and ensure its executable is in PATH.

If switches do not connect:

```bash
sudo mn -c
```

Start the controller before Mininet.

If rerouting is delayed, wait for topology discovery/LLDP processing and inspect the controller log.

Use `ovs-ofctl dump-flows` to verify installed OpenFlow rules.
