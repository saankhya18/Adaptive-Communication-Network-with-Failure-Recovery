# Architecture

The application sends UDP datagrams containing sequence numbers and timestamps.

The SDN controller uses topology information to calculate a path between s1 and s4 and installs OpenFlow 1.3 rules.

Two redundant paths are available:

`h1-s1-s2-s4-h2`

and

`h1-s1-s3-s4-h2`

When the primary link fails, the controller recomputes the path and installs forwarding rules on the alternate path.
