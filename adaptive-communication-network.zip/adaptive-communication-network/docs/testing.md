# Testing

Run unit tests:

```bash
python3 tests/test_protocol.py
python3 tests/test_path_computation.py
```

Run Mininet and check:

```text
mininet> pingall
```

Then run the UDP server/client and test:

```text
mininet> link s1 s2 down
```

Inspect flows with:

```bash
sudo ovs-ofctl -O OpenFlow13 dump-flows s1
```
