# Viva Questions

### Why UDP?
UDP is the protocol assigned for the project and provides datagram communication with low overhead.

### Why SDN?
The controller can observe network topology and program forwarding behavior dynamically.

### Why two paths?
A redundant path is necessary to demonstrate failure recovery.

### What happens during failure?
The controller detects a topology/port change, recomputes a surviving path and installs forwarding rules.

### What is measured?
Packet loss, latency and recovery time.

### What does the application add?
Sequence numbers allow packet-gap detection and timestamps allow latency measurement.

### What is the main limitation?
The implementation targets the supplied Mininet topology and fixed UDP service flow rather than being a production general-purpose controller.
