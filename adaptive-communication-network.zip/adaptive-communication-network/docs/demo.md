# Demo

Start the controller, then Mininet.

Inside Mininet:

```text
h2 python3 app/udp_server.py --bind 10.0.0.2 --port 5001
h1 python3 app/udp_client.py --server 10.0.0.2 --port 5001 --count 1000 --interval 0.05
link s1 s2 down
```

Observe the controller's topology/path change message. Restore the link with:

```text
link s1 s2 up
```
