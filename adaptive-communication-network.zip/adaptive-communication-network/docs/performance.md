# Performance Evaluation

Measure:

- packet loss percentage
- average latency
- maximum latency where collected
- recovery time

Run multiple trials for normal operation and primary-link failure. A static/no-rerouting baseline can be compared with the adaptive controller.

Only report values obtained from actual runs.
